// // Vetor de livros em formato JSON
// const livros = [
//     {
//         codigo: 1,
//         codEditora: 1,
//         titulo: "O Senhor dos Anéis",
//         resumo: "Uma aventura épica na Terra Média.",
//         autores: ["J.R.R. Tolkien"]
//     },
//     {
//         codigo: 2,
//         codEditora: 2,
//         titulo: "1984",
//         resumo: "Um olhar sombrio sobre um futuro distópico.",
//         autores: ["George Orwell"]
//     },
//     {
//         codigo: 3,
//         codEditora: 3,
//         titulo: "Dom Quixote",
//         resumo: "As aventuras de um cavaleiro louco.",
//         autores: ["Miguel de Cervantes"]
//     },
//     {
//         codigo: 4,
//         codEditora: 3,
//         titulo: "A Metamorfose",
//         resumo: "A história de Gregor Samsa, que acorda transformado em um inseto gigante.",
//         autores: ["Franz Kafka"]
//     },
//     {
//         codigo: 5,
//         codEditora: 2,
//         titulo: "O Alquimista",
//         resumo: "A jornada de um jovem pastor em busca de um tesouro, repleta de lições sobre a vida.",
//         autores: ["Paulo Coelho"]
//     },
//     {
//         codigo: 6,
//         codEditora: 1,
//         titulo: "Cem Anos de Solidão",
//         resumo: "A saga da família Buendía na fictícia cidade de Macondo, explorando temas de amor, solidão e destino.",
//         autores: ["Gabriel García Márquez"]
//     },
//     {
//         codigo: 7,
//         codEditora: 2,
//         titulo: "O Pequeno Príncipe",
//         resumo: "Uma história poética sobre um jovem príncipe que viaja por diferentes planetas e aprende lições de vida.",
//         autores: ["Antoine de Saint-Exupéry"]
//     },
//     {
//         codigo: 8,
//         codEditora: 3,
//         titulo: "Orgulho e Preconceito",
//         resumo: "Um romance que examina a moral e os costumes da sociedade britânica no século XIX, através da história de Elizabeth Bennet.",
//         autores: ["Jane Austen"]
//     },
//     {
//         codigo: 9,
//         codEditora: 2,
//         titulo: "A Revolução dos Bichos",
//         resumo: "Uma alegoria sobre a corrupção do socialismo, contada através da história de animais que tomam o controle de uma fazenda.",
//         autores: ["George Orwell"]
//     },
//     {
//         codigo: 10,
//         codEditora: 2,
//         titulo: "Fahrenheit 451",
//         resumo: "Uma distopia em que os livros são proibidos e os 'bombeiros' queimam qualquer um que for encontrado.",
//         autores: ["Ray Bradbury"]
//     },    
// ];

// // Exporta o vetor para ser utilizado em outros arquivos
// export default livros;
