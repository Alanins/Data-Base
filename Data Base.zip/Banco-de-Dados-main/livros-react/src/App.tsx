import React from "react";
import LivroLista from "./LivroLista";

function App() {
  return (
    <div className="App">
      <LivroLista />
    </div>
  );
}

export default App;
